# Tazbeet App - Prioritized Action Plan

## Overview

This document outlines a prioritized action plan based on the comprehensive analysis. Tasks are organized by priority and timeline.

---

## Phase 1: Critical Fixes (Weeks 1-2)

### Security & Stability

| Task | Owner | Effort | Files Affected |
|------|-------|--------|----------------|
| Add Hive encryption for sensitive data | Backend | 4h | `task_repository.dart`, `mood_repository.dart` |
| Add input validation to forms | Full-stack | 8h | `add_task_dialog.dart`, `edit_task_dialog.dart` |
| Mask sensitive data in logs | Backend | 2h | `auth_service.dart`, `analytics_service.dart` |
| Add undo for task deletion | Frontend | 4h | `home_screen.dart`, `task_item.dart` |

### Code Quality

| Task | Owner | Effort | Files Affected |
|------|-------|--------|----------------|
| Enable widget tests with Firebase mocks | QA | 8h | `test/`, `pubspec.yaml` |
| Add TaskListBloc unit tests (15 tests) | QA | 16h | `test/blocs/` |
| Fix DRY violation - extract sync helper | Backend | 2h | `task_list_bloc.dart` |
| Remove commented code blocks | All | 2h | `notification_service.dart`, others |

### Performance

| Task | Owner | Effort | Files Affected |
|------|-------|--------|----------------|
| Enable Firestore offline persistence | Backend | 1h | `main.dart` |
| Add list keys to ListViews | Frontend | 2h | All list widgets |
| Parallelize app initialization | Backend | 4h | `main.dart` |

---

## Phase 2: Refactoring (Weeks 3-4)

### Home Screen Refactor (CRITICAL)

**Goal:** Break `home_screen.dart` (99KB) into manageable components

```
New Structure:
lib/ui/screens/home/
├── home_screen.dart              (~200 lines)
├── components/
│   ├── home_header.dart          (~150 lines)
│   ├── home_quick_stats.dart     (~200 lines)
│   ├── home_calendar_panel.dart  (~300 lines)
│   ├── home_category_chips.dart  (~100 lines)
│   ├── home_task_sections.dart   (~400 lines)
│   ├── home_search_bar.dart      (~100 lines)
│   └── home_fab.dart             (~100 lines)
├── dialogs/
│   ├── home_filter_dialog.dart   (~200 lines)
│   └── home_sort_dialog.dart     (~150 lines)
└── state/
    └── home_state_manager.dart   (~200 lines)
```

**Effort:** 3-5 days  
**Owner:** Senior Developer

### Other Refactoring

| Task | Owner | Effort | Files Affected |
|------|-------|--------|----------------|
| Split settings_screen.dart into sections | Frontend | 2 days | `settings_screen.dart` |
| Extract BLoC sync logic to separate service | Backend | 1 day | `task_list_bloc.dart` |
| Add copyWith to all models | Backend | 4h | `category.dart`, `user.dart` |

---

## Phase 3: Testing & CI (Week 5-6)

### Testing

| Task | Owner | Effort | Target |
|------|-------|--------|--------|
| Add AuthService tests | QA | 1 day | 10 tests |
| Add DataSyncService tests | QA | 2 days | 15 tests |
| Add model unit tests | QA | 1 day | 20 tests |
| Add critical widget tests | QA | 2 days | 10 tests |

**Coverage Target:** 40%

### CI/CD Setup

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  analyze:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
      - run: flutter pub get
      - run: flutter analyze --fatal-infos

  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
      - run: flutter test --coverage
      - uses: codecov/codecov-action@v3

  build-android:
    needs: [analyze, test]
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: subosito/flutter-action@v2
      - run: flutter build apk --release
```

---

## Phase 4: UX Improvements (Weeks 7-8)

### High Impact

| Task | Owner | Effort | Impact |
|------|-------|--------|--------|
| Add sync status indicator | Frontend | 1 day | High |
| Implement progressive home screen | Frontend | 2 days | High |
| Add quick add functionality | Full-stack | 2 days | High |
| Improve empty states | Frontend | 1 day | Medium |

### Accessibility

| Task | Owner | Effort |
|------|-------|--------|
| Add semantic labels to all icons | Frontend | 1 day |
| Add reduced motion support | Frontend | 4h |
| Test with screen readers | QA | 1 day |

---

## Phase 5: New Features (Weeks 9-12)

### Home Screen Widget

**Platforms:** iOS, Android  
**Effort:** 2 weeks  
**Features:**
- Today's tasks (top 3)
- Quick add button
- Progress indicator

### FCM Push Notifications

**Effort:** 1 week  
**Features:**
- Server-triggered reminders
- Admin announcements
- Shared task notifications (future)

### Calendar Integration

**Effort:** 1 week  
**Features:**
- Export tasks to device calendar
- Import calendar events as tasks

---

## Phase 6: Cleanup (Ongoing)

### Feature Removal Timeline

| Feature | Deprecate | Disable | Remove |
|---------|-----------|---------|--------|
| Voice Notes | Week 9 | Week 12 | v2.0 |
| Glass Kit | - | Week 9 | Week 10 |
| Flutter TTS | - | Week 9 | Week 10 |
| General Attachments | Week 9 | Week 12 | v2.0 |

### Dependency Audit

| Package | Action | Timeline |
|---------|--------|----------|
| reorderables | Find alternative | Month 2 |
| glass_kit | Remove | Week 10 |
| flutter_tts | Remove | Week 10 |

---

## Success Metrics

### Code Quality
- [ ] Test coverage: 25% → 50%
- [ ] No files > 500 lines
- [ ] Zero critical lint warnings
- [ ] CI passing on all PRs

### Performance
- [ ] Cold start: < 1.5s
- [ ] Task list load: < 100ms
- [ ] APK size: < 25MB

### Security
- [ ] Hive encryption enabled
- [ ] Input validation on all forms
- [ ] No sensitive data in logs

### UX
- [ ] Sync status visible
- [ ] Undo on all deletions
- [ ] Accessibility audit passed

---

## Resource Requirements

### Team
- 1 Senior Flutter Developer (lead)
- 1 Mid-level Flutter Developer
- 1 QA Engineer (part-time)

### Timeline
- Phase 1-2: 4 weeks
- Phase 3-4: 4 weeks
- Phase 5-6: 4 weeks
- **Total: 12 weeks (1 quarter)**

### Tools Needed
- CI/CD platform (GitHub Actions - free)
- Code coverage tool (Codecov - free tier)
- Firebase Performance Monitoring (included)

---

## Risk Mitigation

| Risk | Mitigation |
|------|------------|
| Home screen refactor breaks features | Feature flag, comprehensive testing |
| User backlash on removed features | 3-month deprecation, user survey |
| CI/CD setup delays | Start simple, iterate |
| Test writing slows development | Dedicate specific sprint |

---

## Review Checkpoints

| Checkpoint | Date | Goals |
|------------|------|-------|
| Week 2 | - | Critical fixes complete, tests enabled |
| Week 4 | - | Home screen refactored, 30% coverage |
| Week 6 | - | CI/CD running, 40% coverage |
| Week 8 | - | UX improvements live, accessibility audit |
| Week 12 | - | New features launched, 50% coverage |

---

## Appendix: Quick Wins

Tasks that can be done in < 2 hours with high impact:

1. ✅ Add undo snackbar for deletions
2. ✅ Enable Firestore offline persistence
3. ✅ Add list keys to all ListViews
4. ✅ Mask email in auth logs
5. ✅ Add sync status icon placeholder
6. ✅ Remove commented code blocks
7. ✅ Add CHANGELOG.md
8. ✅ Update analysis_options.yaml with stricter rules
