# UX Issues & Improvement Recommendations

## Critical UX Issues

### 1. Home Screen Information Overload
**Severity:** HIGH  
**Impact:** User confusion, cognitive load  
**Location:** `home_screen.dart`

**Description:**
The home screen displays too much information simultaneously:
- Quick stats (3-4 cards)
- Calendar panel
- Category filter chips
- Multiple task sections (Today, Tomorrow, This Week, Completed)
- Search bar
- Filter options

**Evidence:**
```
File size: 99KB indicates excessive complexity
Users likely feel overwhelmed on first use
```

**Recommendations:**
1. **Progressive Disclosure:** Show simplified view by default
2. **Collapsible Sections:** Allow users to hide sections
3. **Smart Defaults:** Only show relevant sections based on task count
4. **Guided Tour:** Tutorial highlighting key features

**Proposed Solution:**
```dart
class SimpleHomeView extends StatelessWidget {
  // Default view: Just today's tasks
  // Expandable sections for more
}

class AdvancedHomeView extends StatelessWidget {
  // Full featured view
  // User can switch in settings
}
```

---

### 2. Sync Status Invisible
**Severity:** HIGH  
**Impact:** Data loss anxiety, trust issues  
**Location:** Throughout app

**Description:**
Users have no visibility into:
- Whether data is synced to cloud
- When last sync occurred
- If there are pending changes
- Sync errors

**Recommendations:**
1. Add sync status indicator in app bar
2. Show last sync time in settings
3. Visual indicator for unsaved changes
4. Error toast for sync failures

**Proposed Solution:**
```dart
class SyncStatusIndicator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<SyncService>(
      builder: (context, sync, _) {
        if (sync.isSyncing) {
          return Icon(Icons.sync, color: Colors.blue);
        } else if (sync.hasError) {
          return Icon(Icons.sync_problem, color: Colors.red);
        } else {
          return Icon(Icons.cloud_done, color: Colors.green);
        }
      },
    );
  }
}
```

---

### 3. No Undo for Destructive Actions
**Severity:** HIGH  
**Impact:** Accidental data loss  
**Location:** Task deletion, category deletion

**Description:**
When users delete tasks or categories, the action is immediate with no undo option.

**Current Flow:**
```
Swipe task → Delete button → Gone forever
```

**Recommended Flow:**
```
Swipe task → Delete button → Snackbar with "Undo" → 5 second delay → Permanent delete
```

**Proposed Solution:**
```dart
void _deleteTask(Task task) {
  // Soft delete first
  setState(() => _deletedTasks.add(task));
  
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text('Task deleted'),
      action: SnackBarAction(
        label: 'Undo',
        onPressed: () {
          setState(() => _deletedTasks.remove(task));
        },
      ),
      duration: Duration(seconds: 5),
    ),
  ).closed.then((reason) {
    if (reason != SnackBarClosedReason.action) {
      // Permanently delete
      taskBloc.add(DeleteTask(task.id));
    }
  });
}
```

---

## Medium Priority Issues

### 4. Inconsistent Back Navigation
**Severity:** MEDIUM  
**Impact:** User disorientation  

**Description:**
- Some screens use back button in app bar
- Some use close (X) button
- Some require swipe gesture only
- Deep screens (Task Details → Edit → Subtask) lose context

**Recommendations:**
1. Use back arrow for navigation within hierarchy
2. Use X for dialogs/modals that overlay
3. Add breadcrumbs for deep navigation
4. Preserve scroll position on back

---

### 5. Pomodoro Timer Not Persistent
**Severity:** MEDIUM  
**Impact:** Lost focus sessions  
**Location:** `pomodoro_screen.dart`

**Description:**
When navigating away from Pomodoro tab, timer continues but:
- No indicator visible on other tabs
- App background kills timer
- Lock screen doesn't show progress

**Recommendations:**
1. Add persistent notification during active session
2. Show timer badge on Pomodoro tab
3. Use foreground service on Android
4. Lock screen widget

---

### 6. Search Requires Extra Tap
**Severity:** MEDIUM  
**Impact:** Slower task finding  

**Description:**
To search tasks:
1. Tap search icon
2. Wait for search bar to appear
3. Start typing

**Recommendations:**
- Always show search bar on home screen
- Add keyboard shortcut (desktop)
- Search-as-you-type without tap

---

### 7. Category Colors Hard to Distinguish
**Severity:** MEDIUM  
**Impact:** Visual confusion  

**Description:**
Users can pick any color for categories, but:
- Similar colors (e.g., two blues) are indistinguishable
- Color picker has too many options
- No accessibility consideration for color blindness

**Recommendations:**
1. Provide curated color palette (8-12 distinct colors)
2. Show color preview on task items
3. Add pattern/icon option for color-blind users
4. Warn if color already used

---

## Low Priority Issues

### 8. Empty Calendar Days Waste Space
**Severity:** LOW  
**Impact:** Inefficient screen usage  

**Description:**
Calendar shows all days even when no tasks scheduled, taking valuable screen space.

**Recommendations:**
- Collapse empty weeks
- Show "agenda" view by default
- Only expand calendar when filtering by date

---

### 9. Settings Overwhelming
**Severity:** LOW  
**Impact:** Users may not find settings they need  

**Description:**
Settings screen shows all options in one long list.

**Recommendations:**
- Group into collapsible sections
- Add search within settings
- Highlight new/changed settings
- Show "Popular Settings" section

---

### 10. No Onboarding for Key Features
**Severity:** LOW  
**Impact:** Underused features  

**Description:**
Tutorial exists but:
- Only shows once
- Covers basic navigation
- Doesn't highlight Pomodoro, Mood, Recurring tasks

**Recommendations:**
- Feature discovery prompts ("Did you know?")
- Video tutorials link
- Contextual help tooltips
- Re-accessible tutorial in settings

---

## User Feedback Integration Points

### Recommended Feedback Collection

| Trigger | Type | Goal |
|---------|------|------|
| After 10 tasks completed | In-app survey | Satisfaction score |
| After 7 days of use | App store review prompt | Rating |
| After feature first use | Tooltip feedback | Feature usefulness |
| On error | Bug report option | Issue collection |
| Monthly | Email survey | Deep insights |

### Implementation:
```dart
class FeedbackService {
  Future<void> promptForFeedback(FeedbackType type) async {
    final shouldShow = await _shouldShowFeedback(type);
    if (!shouldShow) return;
    
    switch (type) {
      case FeedbackType.appReview:
        await _showAppStoreReview();
        break;
      case FeedbackType.satisfaction:
        await _showSatisfactionSurvey();
        break;
    }
  }
}
```

---

## Quick Wins (Easy Fixes)

| Issue | Fix | Effort |
|-------|-----|--------|
| No undo on delete | Add snackbar with undo | 2 hours |
| Sync status invisible | Add icon in app bar | 4 hours |
| Search requires tap | Always show search bar | 1 hour |
| Settings overwhelming | Add section headers | 2 hours |
| No loading feedback | Add shimmer everywhere | 4 hours |

---

## Action Items Summary

| Priority | Issue | Effort | Impact |
|----------|-------|--------|--------|
| HIGH | Add undo for deletions | Low | High |
| HIGH | Add sync status indicator | Medium | High |
| HIGH | Simplify home screen | High | High |
| MEDIUM | Persistent Pomodoro notification | Medium | Medium |
| MEDIUM | Improve category color picker | Low | Medium |
| MEDIUM | Fix back navigation consistency | Medium | Medium |
| LOW | Add feature discovery | Medium | Medium |
| LOW | Improve settings organization | Low | Low |
