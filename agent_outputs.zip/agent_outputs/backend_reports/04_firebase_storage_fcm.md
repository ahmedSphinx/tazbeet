# Firebase Storage & Cloud Messaging Analysis

## Firebase Storage

### Current Usage

| Use Case | Status | Implementation |
|----------|--------|----------------|
| User Profile Images | ✅ Used | Via `firebase_storage` package |
| Task Attachments | ✅ Supported | Stored paths in task.attachments |
| Voice Notes | ✅ Supported | Stored paths in task.voiceNotes |
| Backup Files | ⚠️ Planned | Not fully implemented |

### Dependencies
```yaml
firebase_storage: ^12.4.9
image_picker: ^1.1.2
file_picker: ^10.3.3
```

---

## 🟢 Strengths

1. **Modern SDK Version** - Using latest Firebase Storage 12.4.9
2. **Multiple File Types** - Supports images, files, and voice notes
3. **Flexible Attachment System** - Task model supports arrays of attachment paths

---

## 🔴 Issues & Recommendations

### 1. No Upload Progress Tracking
**Severity:** MEDIUM  
**Issue:** Users don't see upload progress for large files.

**Recommendation:**
```dart
Future<String> uploadFileWithProgress(
  File file, 
  String path,
  Function(double) onProgress,
) async {
  final ref = FirebaseStorage.instance.ref(path);
  final uploadTask = ref.putFile(file);
  
  uploadTask.snapshotEvents.listen((event) {
    final progress = event.bytesTransferred / event.totalBytes;
    onProgress(progress);
  });
  
  await uploadTask;
  return await ref.getDownloadURL();
}
```

### 2. No File Size Limits
**Severity:** MEDIUM  
**Issue:** No client-side validation of file sizes before upload.

**Recommendation:**
```dart
const int maxFileSizeMB = 10;

Future<bool> validateFileSize(File file) async {
  final sizeInBytes = await file.length();
  final sizeInMB = sizeInBytes / (1024 * 1024);
  return sizeInMB <= maxFileSizeMB;
}
```

### 3. No Image Compression
**Severity:** MEDIUM  
**Issue:** Images uploaded at full resolution, wasting storage and bandwidth.

**Recommendation:**
```dart
import 'package:flutter_image_compress/flutter_image_compress.dart';

Future<File> compressImage(File file) async {
  final result = await FlutterImageCompress.compressWithFile(
    file.absolute.path,
    quality: 70,
    minWidth: 1024,
    minHeight: 1024,
  );
  // Save and return compressed file
}
```

### 4. No Offline Upload Queue
**Severity:** MEDIUM  
**Issue:** Uploads fail silently when offline.

**Recommendation:** Implement upload queue:
```dart
class UploadQueue {
  final List<PendingUpload> _queue = [];
  
  void enqueue(File file, String path) {
    _queue.add(PendingUpload(file, path));
    _processQueue();
  }
  
  Future<void> _processQueue() async {
    if (!await isConnected()) return;
    // Process pending uploads
  }
}
```

### 5. Storage Security Rules Missing
**Severity:** HIGH  
**Issue:** No visible storage security rules in project.

**Recommendation:** Create `storage.rules`:
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{userId}/{allPaths=**} {
      allow read: if request.auth != null && request.auth.uid == userId;
      allow write: if request.auth != null && request.auth.uid == userId
                   && request.resource.size < 10 * 1024 * 1024
                   && request.resource.contentType.matches('image/.*|audio/.*|application/pdf');
    }
  }
}
```

### 6. No Cleanup for Orphaned Files
**Severity:** LOW  
**Issue:** When tasks are deleted, attachments may remain in storage.

**Recommendation:**
```dart
Future<void> deleteTaskWithAttachments(Task task) async {
  // Delete attachments from storage
  for (final path in task.attachments) {
    await FirebaseStorage.instance.ref(path).delete();
  }
  for (final path in task.voiceNotes) {
    await FirebaseStorage.instance.ref(path).delete();
  }
  // Then delete task
  await taskRepository.deleteTask(task.id);
}
```

---

## Firebase Cloud Messaging (FCM)

### Current Status
**NOT IMPLEMENTED** - App uses `flutter_local_notifications` only.

### Current Notification Implementation

| Feature | Status | Notes |
|---------|--------|-------|
| Local Notifications | ✅ Active | Task reminders, mood check-ins |
| Push Notifications (FCM) | ❌ Missing | No server-triggered notifications |
| Background Notifications | ⚠️ Partial | WorkManager for scheduled tasks |

### Why FCM is Needed

1. **Admin Announcements** - Send updates to all users
2. **Collaborative Features** - Notify when shared tasks change
3. **Server-Triggered Reminders** - More reliable than local scheduling
4. **Engagement Campaigns** - Re-engagement notifications

---

## FCM Implementation Recommendation

### 1. Add Dependencies
```yaml
firebase_messaging: ^15.0.0
```

### 2. Create FCM Service
```dart
class FCMService {
  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  
  Future<void> initialize() async {
    // Request permission
    await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    
    // Get token
    final token = await _messaging.getToken();
    await _saveTokenToFirestore(token);
    
    // Handle messages
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);
    FirebaseMessaging.onBackgroundMessage(_handleBackgroundMessage);
  }
  
  Future<void> _saveTokenToFirestore(String? token) async {
    if (token == null) return;
    await FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .update({'fcmToken': token});
  }
}
```

### 3. Cloud Function for Sending
```javascript
exports.sendTaskReminder = functions.firestore
  .document('users/{userId}/tasks/{taskId}')
  .onUpdate(async (change, context) => {
    const task = change.after.data();
    const user = await admin.firestore()
      .collection('users')
      .doc(context.params.userId)
      .get();
    
    if (task.reminderDate && user.data().fcmToken) {
      await admin.messaging().send({
        token: user.data().fcmToken,
        notification: {
          title: 'Task Reminder',
          body: task.title,
        },
        data: {
          taskId: context.params.taskId,
          type: 'task_reminder',
        },
      });
    }
  });
```

---

## Remote Config

### Current Status
**NOT IMPLEMENTED**

### Recommended Use Cases

| Feature | Use Case |
|---------|----------|
| Feature Flags | A/B testing new features |
| Maintenance Mode | Already using admin_settings, could use Remote Config |
| Onboarding Flow | Dynamic onboarding steps |
| Default Values | Pomodoro durations, default categories |
| Promotions | In-app messages, banners |

### Implementation Suggestion
```dart
class RemoteConfigService {
  final FirebaseRemoteConfig _remoteConfig = FirebaseRemoteConfig.instance;
  
  Future<void> initialize() async {
    await _remoteConfig.setDefaults({
      'pomodoro_work_duration': 25,
      'pomodoro_break_duration': 5,
      'show_tutorial': true,
      'max_subtask_depth': 3,
    });
    
    await _remoteConfig.fetchAndActivate();
  }
  
  int get pomodoroWorkDuration => _remoteConfig.getInt('pomodoro_work_duration');
}
```

---

## Action Items

| Priority | Task | Effort | Impact |
|----------|------|--------|--------|
| HIGH | Add Storage security rules | Low | High |
| HIGH | Implement FCM for push notifications | High | High |
| MEDIUM | Add upload progress tracking | Low | Medium |
| MEDIUM | Implement image compression | Medium | Medium |
| MEDIUM | Add file size validation | Low | Medium |
| LOW | Implement Remote Config | Medium | Medium |
| LOW | Add orphaned file cleanup | Medium | Low |
