# Known Issues & Technical Debt

## Critical Issues

### 1. Home Screen File Size
**Severity:** CRITICAL  
**File:** `lib/ui/screens/home/home_screen.dart`  
**Size:** 99KB (~2500+ lines)

**Impact:**
- Extremely difficult to maintain
- Long build times for hot reload
- High risk of merge conflicts
- Impossible to test effectively
- Performance concerns with rebuilds

**Status:** Needs immediate refactoring (see Phase 2 in Action Plan)

---

### 2. Race Condition in Task Sync (Partially Fixed)
**Severity:** HIGH  
**File:** `lib/blocs/task_list/task_list_bloc.dart`

**Background:** Previously identified and fixed, but user reverted some changes.

**Current State:**
```dart
// Fixed: Persist FIRST, then emit
await taskRepository.addTask(event.task);
final List<Task> updatedTasks = List.from((state as TaskListLoaded).tasks)..add(event.task);
emit(TaskListLoaded(updatedTasks));
```

**Remaining Concern:** Firestore sync still async with no error recovery:
```dart
try {
  await _dataSyncService.syncToFirestore(user.uid);
} catch (e) {
  AppLogging.logInfo('Failed to sync...'); // Just logs, no recovery
}
```

**Recommendation:** Add retry queue for failed syncs.

---

### 3. Task ID Generation Collision Risk
**Severity:** MEDIUM  
**File:** `lib/blocs/task_details/task_details_bloc.dart`

**Issue:** Task duplication uses timestamp which could collide under rapid operations.

**Current (at risk):**
```dart
id: DateTime.now().millisecondsSinceEpoch.toString(),
```

**Recommendation:**
```dart
import 'package:uuid/uuid.dart';
id: Uuid().v4(),
```

---

### 4. No MFA Authentication
**Severity:** HIGH  
**File:** `lib/services/auth_service.dart`

**Impact:** Accounts with weak passwords vulnerable to compromise.

**Status:** Not implemented. See Security Report for implementation plan.

---

### 5. Unencrypted Local Storage
**Severity:** MEDIUM  
**Files:** All repositories using Hive

**Impact:** Device with physical access could read user's tasks and moods.

**Status:** Hive encryption not enabled. See Security Report.

---

## Medium Priority Issues

### 6. Disabled Widget Tests
**Severity:** MEDIUM  
**File:** `test/widget_test.dart`

**Current State:**
```dart
void main() {
  // Widget tests disabled - requires full app initialization
  test('placeholder test', () {
    expect(true, isTrue);
  });
}
```

**Impact:** No UI testing coverage.

**Solution:** Mock Firebase services (see Testing Report).

---

### 7. Inconsistent Error Handling
**Severity:** MEDIUM  
**Files:** Multiple

**Examples:**
- Some methods throw exceptions, others return null
- Catch blocks often just log without recovery
- No Result/Either type for error handling

---

### 8. Large Admin Panel Screen
**Severity:** MEDIUM  
**File:** `lib/ui/screens/admin_panel_screen.dart`  
**Size:** 49KB

**Impact:** Difficult to maintain, but lower priority than home_screen.

---

### 9. Commented Out Code
**Severity:** LOW  
**File:** `lib/services/notification_service.dart`

**Issue:** 100+ lines of commented code:
```dart
/* 
  Future<void> scheduleMoodCheckInNotifications(...) {
    // ... large block
  }
*/
```

**Action:** Remove or restore based on functionality needs.

---

### 10. Missing Firestore Indexes
**Severity:** MEDIUM  
**File:** Missing `firestore.indexes.json`

**Impact:** Some queries may be slow or fail.

**Action:** Add composite indexes for common query patterns.

---

## Low Priority Issues

### 11. Magic Numbers
**Severity:** LOW  
**Files:** Multiple

**Examples:**
```dart
Timer(const Duration(milliseconds: 300), ...);
maxSubtaskDepth: 3
reminderIntervals: [30, 60]
```

**Action:** Extract to named constants.

---

### 12. Inconsistent Naming
**Severity:** LOW

**Examples:**
- `moodNotificationChannelId` vs `_boxName`
- Mixed Arabic/English comments

---

### 13. Deprecated Package Warnings
**Severity:** LOW  
**Package:** `reorderables` (last update 2+ years ago)

**Action:** Monitor for alternatives.

---

## Technical Debt Backlog

| ID | Issue | Severity | Effort | Status |
|----|-------|----------|--------|--------|
| TD-001 | home_screen.dart too large | Critical | High | Planned |
| TD-002 | Race condition partial fix | High | Low | Monitor |
| TD-003 | Task ID collision risk | Medium | Low | Backlog |
| TD-004 | No MFA | High | Medium | Planned |
| TD-005 | Unencrypted Hive | Medium | Medium | Planned |
| TD-006 | Widget tests disabled | Medium | Medium | Planned |
| TD-007 | Inconsistent error handling | Medium | High | Backlog |
| TD-008 | Admin panel large | Medium | Medium | Backlog |
| TD-009 | Commented code | Low | Low | Backlog |
| TD-010 | Missing Firestore indexes | Medium | Low | Backlog |
| TD-011 | Magic numbers | Low | Low | Backlog |
| TD-012 | Inconsistent naming | Low | Low | Backlog |
| TD-013 | reorderables deprecated | Low | Medium | Monitor |

---

## Bug Tracking

### Open Bugs (from memory)

| Bug | Severity | Fixed | Notes |
|-----|----------|-------|-------|
| Multiple heroes share same tag | Medium | ✅ | Unique heroTags added |
| No Material widget in AddTaskDialog | High | ✅ | Wrapped in Dialog |
| LateInitializationError in MoodScreen | High | ✅ | TabController passed via constructor |
| Tutorial logic shadowing | Medium | ✅ | Variable shadowing fixed |
| Overdue filter wrong logic | Medium | ✅ | showOverdueOnly flag added |

### Potential Bugs (need verification)

| Suspected Issue | Location | Needs Testing |
|-----------------|----------|---------------|
| Sync fails silently | TaskListBloc | Yes |
| Calendar doesn't show all events | home_screen | Unknown |
| Notifications may not fire | NotificationService | Yes |
| Subtask count may be wrong | CategoryRepository | Partially fixed |

---

## Monitoring Recommendations

### Add Logging For
1. Sync failures (with retry count)
2. Authentication errors
3. Notification scheduling failures
4. Large task lists (>500 items)
5. Long screen render times

### Add Analytics For
1. Feature usage (which features used)
2. Error rates by screen
3. Sync success rate
4. Session duration
5. Task completion patterns

---

## Regular Maintenance Tasks

### Weekly
- [ ] Review Crashlytics reports
- [ ] Check Firebase usage quotas
- [ ] Review pending security updates

### Monthly
- [ ] Dependency update audit
- [ ] Performance metrics review
- [ ] User feedback review
- [ ] Technical debt triage

### Quarterly
- [ ] Security audit
- [ ] Code quality metrics
- [ ] Architecture review
- [ ] Test coverage assessment
