# Unnecessary & Underutilized Features Analysis

## Feature Utilization Assessment

### Feature Value Matrix

| Feature | Development Cost | Maintenance Cost | User Value | Recommendation |
|---------|-----------------|------------------|------------|----------------|
| Voice Notes | High | Medium | Low | Remove or Simplify |
| File Attachments | Medium | Low | Low | Simplify to Images |
| Admin Panel | High | Medium | Low (few users) | Keep but Freeze |
| Ambient Sounds | Medium | Low | Low | Make Optional Plugin |
| Glass Kit Effects | Low | Low | Very Low | Remove |
| Text-to-Speech | Medium | Low | Very Low | Remove |
| Facebook Login | - | - | - | ✅ Already Removed |

---

## Features to Remove/Simplify

### 1. Voice Notes 📝➡️🗑️

**Current State:**
- `flutter_tts` package included
- Voice note paths stored in Task model
- Recording/playback UI somewhere

**Why Remove:**
- Complex implementation for mobile
- Storage costs on Firebase
- Very few users likely use this
- Increases app size
- Maintenance burden

**Removal Steps:**
```dart
// 1. Remove from Task model
// Before:
final List<String> voiceNotes;

// After:
// Remove field entirely or deprecate

// 2. Remove dependency
// pubspec.yaml
// - flutter_tts: ^4.1.0  ← Remove

// 3. Remove UI components
// Delete voice recording widgets
```

**Alternative:** If voice input is desired, use speech-to-text for task title instead.

---

### 2. General File Attachments 📎➡️📷

**Current State:**
```dart
final List<String> attachments; // In Task model
```

**Why Simplify:**
- Generic file attachments rarely used in task apps
- PDF/document viewing adds complexity
- Storage costs

**Recommendation:** Simplify to image-only:
```dart
// Before
final List<String> attachments; // Any file type

// After
final List<String> images; // Only images
// - Task photos (receipts, whiteboards)
// - Screenshots
// - Reference images
```

**Benefits:**
- Simpler UI (image gallery vs file browser)
- Native image compression
- Built-in preview
- Common use case for tasks

---

### 3. Glass Kit Effects 🪟➡️🗑️

**Package:** `glass_kit: ^3.0.0`

**Current Usage:** Likely minimal or decorative only

**Why Remove:**
- Adds to app size
- Performance overhead
- Modern Material 3 has similar effects built-in
- Small package with uncertain maintenance

**Removal:**
```yaml
# pubspec.yaml
dependencies:
  # glass_kit: ^3.0.0  ← Remove
```

Replace with Material 3:
```dart
// Use built-in blur effects
BackdropFilter(
  filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
  child: Container(
    color: Colors.white.withOpacity(0.2),
  ),
)
```

---

### 4. Text-to-Speech 🔊➡️🗑️

**Package:** `flutter_tts: ^4.1.0`

**Current Usage:** Unknown, likely minimal

**Why Remove:**
- Niche accessibility feature
- System TTS is available on all platforms
- Adds ~1MB to app size
- Rarely used in task apps

**Alternative:** 
- Rely on system accessibility features (VoiceOver, TalkBack)
- These work automatically with proper semantic labels

---

### 5. Ambient Sounds (Consider Plugin) 🎵➡️📦

**Current State:**
- `AmbientService` with multiple sound files
- Custom audio player implementation
- Sound assets increase app size

**Options:**

**Option A: Remove entirely**
- Direct users to dedicated apps (Noisli, Calm, etc.)
- Reduces app size by 1-2MB
- Removes maintenance burden

**Option B: Make optional download**
```dart
class AmbientSoundsPlugin {
  static Future<void> downloadSoundPack() async {
    // Download sounds on-demand from Firebase Storage
    // Not bundled with app
  }
}
```

**Option C: External integration**
```dart
// Just link to Spotify/Apple Music focus playlists
Future<void> openFocusPlaylist() async {
  await launchUrl(Uri.parse('spotify:playlist:focus_music'));
}
```

---

## Features to Freeze (No New Development)

### 1. Admin Panel 🔒

**Current State:** 49KB file with comprehensive admin features

**Recommendation:** Keep but freeze
- Don't add new admin features
- Only bug fixes
- Consider moving to web dashboard long-term

**Justification:**
- Very few admin users
- High complexity
- Works well enough for current needs

### 2. Emergency Mode 🚨

**Location:** `emergency_service.dart`, `emergency_screen.dart`

**Current State:** 5KB service, 8KB screen

**Recommendation:** Freeze
- Niche feature
- Maintenance mode covers most cases
- Keep functional but don't enhance

---

## Features to Invest In Instead

### Resource Reallocation

| Remove/Reduce | Invest In |
|---------------|-----------|
| Voice Notes | Quick Add (Share extension) |
| File Attachments | Image-only attachments |
| Glass Kit | Native Material 3 effects |
| TTS | Proper accessibility labels |
| Complex Ambient | Spotify/Music integration |

### Development Time Saved

| Feature Removal | Est. Time Saved (yearly) |
|-----------------|--------------------------|
| Voice Notes | 2-4 weeks |
| General Attachments | 1-2 weeks |
| Glass Kit | 1-2 days |
| TTS | 1 week |
| Ambient (if removed) | 2-3 weeks |
| **Total** | **7-12 weeks** |

---

## Migration Plan

### Phase 1: Deprecate (Week 1-2)
```dart
@Deprecated('Voice notes will be removed in v2.0')
final List<String> voiceNotes;

// Add migration notice in app
if (task.voiceNotes.isNotEmpty) {
  showDeprecationWarning('Voice notes will be removed. Please save your recordings.');
}
```

### Phase 2: Disable New Usage (Week 3-4)
- Hide voice note creation UI
- Keep playback for existing notes
- Log usage to verify low adoption

### Phase 3: Remove (v2.0)
- Remove voice notes from Task model
- Clean up storage (offer export first)
- Remove packages

---

## Impact Assessment

### Positive Impacts
- Smaller app size (~3-5MB reduction)
- Faster build times
- Reduced crash surface
- Lower Firebase Storage costs
- Simplified codebase
- Easier onboarding for new developers

### Negative Impacts
- Some users may miss features
- Migration effort required
- Need deprecation period

### Mitigation
- Survey users before removal
- Provide data export
- 3-month deprecation notice
- Blog post explaining focus on core features

---

## Action Items

| Priority | Action | Effort | Impact |
|----------|--------|--------|--------|
| HIGH | Deprecate voice notes | Low | Medium |
| HIGH | Simplify attachments to images | Medium | Medium |
| MEDIUM | Remove glass_kit | Low | Low |
| MEDIUM | Remove flutter_tts | Low | Low |
| LOW | Evaluate ambient sounds | Medium | Low |
| LOW | Freeze admin panel | - | - |
