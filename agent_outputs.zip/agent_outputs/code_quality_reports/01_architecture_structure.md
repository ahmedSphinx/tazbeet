# Code Architecture & Structure Analysis

## Overall Architecture

### Pattern: Clean Architecture + BLoC

```
┌─────────────────────────────────────────────────────────┐
│                    UI Layer                              │
│  screens/ widgets/ controllers/ themes/                  │
├─────────────────────────────────────────────────────────┤
│                    BLoC Layer                            │
│  auth/ task_list/ task_details/ category/ mood/ user/    │
├─────────────────────────────────────────────────────────┤
│                  Repository Layer                        │
│  task_repository/ category_repository/ mood_repository/  │
├─────────────────────────────────────────────────────────┤
│                   Services Layer                         │
│  auth/ notification/ sync/ analytics/ pomodoro/ etc.     │
├─────────────────────────────────────────────────────────┤
│                    Data Layer                            │
│  Hive (Local) / Firestore (Remote) / SharedPreferences   │
└─────────────────────────────────────────────────────────┘
```

---

## Project Structure

```
lib/
├── main.dart                    # Entry point (263 lines)
├── firebase_options.dart        # Firebase config
├── blocs/                       # 7 BLoC modules
│   ├── auth/
│   ├── category/
│   ├── mood/
│   ├── notification/
│   ├── task_details/
│   ├── task_list/
│   └── user/
├── models/                      # 13 data models
├── repositories/                # 5 repositories
├── services/                    # 23 services
├── ui/
│   ├── screens/                 # 29 screens
│   ├── widgets/                 # 29 widgets
│   ├── controllers/             # 1 controller
│   ├── design_system/           # 6 design components
│   └── themes/                  # 2 theme files
├── l10n/                        # 10 localization files
└── utils/                       # 2 utility files
```

---

## 🟢 Architecture Strengths

### 1. Clear Layer Separation
- BLoCs handle state management
- Repositories abstract data access
- Services encapsulate business logic
- UI components are reusable

### 2. Dependency Injection
```dart
// Good: Dependencies injected in main.dart
BlocProvider<TaskListBloc>(
  create: (context) => TaskListBloc(
    taskRepository: context.read<TaskRepository>(),
    categoryRepository: context.read<CategoryRepository>(),
    notificationService: notificationService
  ),
),
```

### 3. Singleton Services
```dart
// Consistent singleton pattern
static final DataSyncService _instance = DataSyncService._internal();
factory DataSyncService() => _instance;
```

### 4. Provider Pattern for Services
```dart
MultiProvider(
  providers: [
    Provider<TaskRepository>.value(value: taskRepository),
    ChangeNotifierProvider.value(value: settingsService),
    Provider<AnalyticsService>.value(value: analyticsService),
  ],
)
```

---

## 🔴 Architecture Issues

### 1. Massive Screen Files
**Severity:** HIGH

| File | Lines | Status |
|------|-------|--------|
| `home_screen.dart` | 99,315 bytes (~2500+ lines) | ❌ Critical |
| `admin_panel_screen.dart` | 49,316 bytes (~1200+ lines) | ❌ Needs refactoring |
| `settings_screen.dart` | 40,589 bytes (~1000+ lines) | ⚠️ Should split |
| `main_screen.dart` | 40,370 bytes (~1000+ lines) | ⚠️ Should split |

**Recommendation:** Split `home_screen.dart` into:
```
home/
├── home_screen.dart           # Main container
├── home_header.dart           # Header section
├── home_task_list.dart        # Task list section
├── home_calendar.dart         # Calendar section
├── home_quick_stats.dart      # Stats section
├── home_filters.dart          # Filter controls
└── home_dialogs.dart          # All dialogs
```

### 2. Mixed Responsibilities in BLoC
**Severity:** MEDIUM

`TaskListBloc` handles too many concerns:
- Task CRUD operations
- Recurring task generation
- Notifications
- Firestore sync
- Sound playing

**Recommendation:** Extract to separate services:
```dart
class TaskListBloc {
  // Only handle state management
}

class TaskSyncUseCase {
  // Handle sync logic
}

class RecurringTaskUseCase {
  // Handle recurring logic
}
```

### 3. Inconsistent Model Immutability
**Severity:** MEDIUM

`Task` model uses `copyWith` properly, but some models lack it:
- `Category` - Missing `copyWith`
- `User` - Missing `copyWith`

**Recommendation:** Add `copyWith` to all models.

### 4. Repository vs Service Confusion
**Severity:** LOW

Some data access in services, some in repositories:
- `DataSyncService` directly accesses repositories
- `SettingsService` uses SharedPreferences directly

**Recommendation:** Standardize:
- Repositories: Pure data access (Hive, Firestore)
- Services: Business logic using repositories

### 5. No Use Case Layer
**Severity:** LOW

Missing explicit use case layer for complex operations.

**Recommendation:** Add use cases for:
```dart
class CreateRecurringTaskUseCase {
  final TaskRepository taskRepository;
  final RepeatService repeatService;
  
  Future<Task> execute(Task template, RepeatRule rule) async {
    // Complex logic here
  }
}
```

---

## File Size Analysis

### Largest Files (Need Refactoring)

| File | Size | Recommendation |
|------|------|----------------|
| `home_screen.dart` | 99KB | **URGENT: Split into 5-10 files** |
| `admin_panel_screen.dart` | 49KB | Split into tabs/sections |
| `settings_screen.dart` | 41KB | Extract settings sections |
| `main_screen.dart` | 40KB | Extract tab content |
| `login_screen.dart` | 29KB | Extract form components |
| `notification_service.dart` | 27KB | Split by notification type |

### Good Sized Files (Follow This Pattern)

| File | Size | Notes |
|------|------|-------|
| `task.dart` | 10KB | Good model size |
| `auth_service.dart` | 13KB | Acceptable for auth logic |
| `task_item.dart` | 12KB | Reasonable widget size |

---

## Module Coupling Analysis

### High Coupling (Problematic)

```
TaskListBloc
  ├── TaskRepository
  ├── CategoryRepository
  ├── NotificationService
  ├── DataSyncService
  ├── TaskSoundService
  └── RepeatService
```

**Recommendation:** Use facade pattern:
```dart
class TaskFacade {
  final TaskRepository _taskRepo;
  final CategoryRepository _categoryRepo;
  final NotificationService _notificationService;
  
  Future<void> addTask(Task task) async {
    await _taskRepo.addTask(task);
    await _notificationService.scheduleReminder(task);
    await _categoryRepo.updateCounts();
  }
}
```

---

## Design Patterns Used

| Pattern | Usage | Quality |
|---------|-------|---------|
| **Singleton** | Services | ✅ Good |
| **BLoC** | State management | ✅ Good |
| **Repository** | Data access | ⚠️ Partial |
| **Factory** | Models (fromJson) | ✅ Good |
| **Provider** | DI | ✅ Good |
| **Observer** | ValueNotifier | ✅ Good |
| **Adapter** | Hive adapters | ✅ Good |

---

## Action Items

| Priority | Task | Effort | Impact |
|----------|------|--------|--------|
| HIGH | Refactor home_screen.dart | High | High |
| HIGH | Reduce BLoC responsibilities | Medium | High |
| MEDIUM | Add copyWith to all models | Low | Medium |
| MEDIUM | Standardize repo/service roles | Medium | Medium |
| LOW | Add use case layer | High | Medium |
| LOW | Document architecture decisions | Low | Low |
