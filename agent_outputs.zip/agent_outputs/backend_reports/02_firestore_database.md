# Firestore Database Analysis

## Data Structure

### Collections Hierarchy
```
users/
├── {userId}/
│   ├── [User Document]
│   ├── tasks/{taskId}
│   ├── categories/{categoryId}
│   ├── moods/{moodId}
│   ├── notification_preferences/{prefId}
│   ├── notification_history/{notificationId}
│   └── settings/user_settings
│
admin_settings/
├── app_settings (maintenance mode, etc.)
│
admin_activity_log/
├── {activityId}
│
notification_items/
└── {notificationId}
```

---

## Security Rules Analysis

### File: `firestore.rules`

### 🟢 Strengths
1. **Proper Authentication Checks** - Uses `isAuthenticated()` helper
2. **Owner Verification** - `isOwner(userId)` validates data access
3. **Admin Role System** - Proper admin privilege handling
4. **Admin Field Protection** - Users cannot elevate their own admin status

### 🔴 Issues & Vulnerabilities

#### 1. Admin Check Performance Issue
**Severity:** MEDIUM  
**Location:** Lines 14-17
```javascript
function isAdmin() {
  return isAuthenticated() && 
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true;
}
```
**Issue:** Every admin check requires a document read, which counts against read quotas.

**Recommendation:** Use Custom Claims instead:
```javascript
function isAdmin() {
  return request.auth.token.admin == true;
}
```

#### 2. Overly Permissive Subcollection Rules
**Severity:** MEDIUM  
**Location:** Lines 40-67
```javascript
match /tasks/{taskId} {
  allow read, write: if isOwner(userId) || isAdmin();
}
```
**Issue:** No validation of task data structure or size limits.

**Recommendation:** Add data validation:
```javascript
match /tasks/{taskId} {
  allow read: if isOwner(userId) || isAdmin();
  allow create, update: if (isOwner(userId) || isAdmin()) && 
    request.resource.data.title is string &&
    request.resource.data.title.size() <= 200 &&
    request.resource.data.keys().hasOnly(['title', 'description', 'priority', ...]);
}
```

#### 3. No Rate Limiting
**Severity:** MEDIUM  
**Issue:** No write rate limiting, potential for abuse.

**Recommendation:** Add write rate limits using Firestore rules or Cloud Functions.

#### 4. Admin Settings Readable by All
**Severity:** LOW  
**Location:** Lines 77-81
```javascript
match /admin_settings/{settingId} {
  allow read: if true;  // Needed for maintenance mode
}
```
**Issue:** This is intentional for maintenance mode but could expose admin configuration.

**Recommendation:** Be selective about what's stored in admin_settings.

---

## Data Sync Service Analysis

### File: `lib/services/data_sync_service.dart`

### 🟢 Strengths
1. **Bi-directional Sync** - Both to and from Firestore
2. **Batch Operations** - Uses batch writes for efficiency
3. **Deletion Handling** - Properly syncs deletions

### 🔴 Issues

#### 1. Full Collection Sync
**Severity:** HIGH  
**Location:** `_syncTasksFromFirestore()`
```dart
final snapshot = await tasksRef.get();  // Gets ALL tasks
await _taskRepository.clearAllTasks();  // Clears ALL local
```
**Issue:** On every sync, all tasks are fetched and local storage is cleared. Inefficient for large datasets.

**Recommendation:** Implement incremental sync:
```dart
Future<void> _syncTasksFromFirestore(String userId, {DateTime? lastSyncTime}) async {
  Query query = tasksRef;
  if (lastSyncTime != null) {
    query = query.where('updatedAt', isGreaterThan: lastSyncTime.toIso8601String());
  }
  // Merge instead of replace
}
```

#### 2. No Conflict Resolution
**Severity:** MEDIUM  
**Location:** Throughout sync methods
**Issue:** If same task modified locally and remotely, remote always wins.

**Recommendation:** Implement timestamp-based conflict resolution:
```dart
Task resolveConflict(Task local, Task remote) {
  return local.updatedAt.isAfter(remote.updatedAt) ? local : remote;
}
```

#### 3. No Sync Status Tracking
**Severity:** MEDIUM  
**Issue:** No way for users to know sync status or failed items.

**Recommendation:** Add sync status tracking:
```dart
enum SyncStatus { synced, pending, failed }
// Add to each model
```

#### 4. Missing Firestore Indexes
**Severity:** MEDIUM  
**Issue:** No `firestore.indexes.json` file for composite queries.

**Recommendation:** Create indexes for common queries:
```json
{
  "indexes": [
    {
      "collectionGroup": "tasks",
      "fields": [
        { "fieldPath": "dueDate", "order": "ASCENDING" },
        { "fieldPath": "isCompleted", "order": "ASCENDING" }
      ]
    }
  ]
}
```

---

## Query Efficiency

### Current Queries Analysis

| Query Location | Pattern | Issue | Recommendation |
|----------------|---------|-------|----------------|
| `getAllTasks()` | Get all | O(n) | Add pagination |
| Task filtering | Client-side | Inefficient | Server-side filtering |
| Category tasks | Multiple reads | N+1 problem | Denormalize count |

---

## Storage Optimization

### Task Document Size
Current Task model has 24 fields. Consider:
1. **Subtasks Embedding** - Good for reads, bad for writes on large trees
2. **Pomodoro Sessions Array** - Can grow unbounded

**Recommendation:** Move pomodoro sessions to subcollection for heavy users:
```
tasks/{taskId}/pomodoro_sessions/{sessionId}
```

---

## Action Items

| Priority | Task | Effort | Impact |
|----------|------|--------|--------|
| HIGH | Implement incremental sync | High | High |
| HIGH | Add Firestore indexes | Low | Medium |
| MEDIUM | Use Custom Claims for admin | Medium | Medium |
| MEDIUM | Add data validation rules | Medium | High |
| MEDIUM | Implement conflict resolution | High | Medium |
| LOW | Add sync status tracking | Medium | Medium |
