# Testing & Coverage Analysis

## Current Test Status

### Test Files
```
test/
├── calendar_helpers_test.dart     (4,287 bytes) - Unit tests
├── date_range_test.dart           (2,127 bytes) - Unit tests
├── home_screen_controller_test.dart (2,195 bytes) - Unit tests
└── widget_test.dart               (3,263 bytes) - DISABLED
```

### Coverage Assessment

| Category | Status | Coverage |
|----------|--------|----------|
| **Unit Tests** | ⚠️ Minimal | ~5% |
| **Widget Tests** | ❌ Disabled | 0% |
| **Integration Tests** | ❌ None | 0% |
| **E2E Tests** | ❌ None | 0% |

---

## Current Test Analysis

### 1. widget_test.dart - DISABLED

```dart
void main() {
  // Widget tests disabled - requires full app initialization
  test('placeholder test', () {
    expect(true, isTrue);
  });
}
```

**Issue:** Widget tests require Firebase initialization which fails in test environment.

**Solution:** Mock Firebase services:
```dart
void main() {
  setUpAll(() {
    // Mock Firebase
    TestWidgetsFlutterBinding.ensureInitialized();
    setupFirebaseCoreMocks();
  });
  
  testWidgets('App loads', (tester) async {
    await tester.pumpWidget(
      MaterialApp(home: MockedTazbeet()),
    );
  });
}
```

### 2. date_range_test.dart - Good

```dart
// Tests DateRange utility class
// Good example of focused unit testing
```

### 3. home_screen_controller_test.dart - Basic

```dart
// Tests HomeScreenController
// Missing edge cases and error scenarios
```

---

## 🔴 Critical Untested Areas

### 1. Authentication Flow
**Risk:** HIGH  
**Untested:**
- Login success/failure
- Token refresh
- Logout cleanup
- Sign-up validation

**Recommended Tests:**
```dart
group('AuthService', () {
  late AuthService authService;
  late MockFirebaseAuth mockAuth;
  
  setUp(() {
    mockAuth = MockFirebaseAuth();
    authService = AuthService(auth: mockAuth);
  });
  
  test('signInWithGoogle returns UserCredential on success', () async {
    when(mockAuth.signInWithCredential(any))
        .thenAnswer((_) async => MockUserCredential());
    
    final result = await authService.signInWithGoogle();
    expect(result, isNotNull);
  });
  
  test('signInWithGoogle throws on cancelled', () async {
    when(mockGoogleSignIn.signIn()).thenAnswer((_) async => null);
    
    final result = await authService.signInWithGoogle();
    expect(result, isNull);
  });
  
  test('signOut clears all caches', () async {
    await authService.signOut();
    
    verify(mockHive.box('tasks').clear()).called(1);
    verify(mockHive.box('categories').clear()).called(1);
  });
});
```

### 2. Task Operations
**Risk:** HIGH  
**Untested:**
- Task CRUD operations
- Subtask hierarchy
- Recurring task generation
- Sync logic

**Recommended Tests:**
```dart
group('TaskListBloc', () {
  late TaskListBloc bloc;
  late MockTaskRepository mockRepo;
  
  setUp(() {
    mockRepo = MockTaskRepository();
    bloc = TaskListBloc(taskRepository: mockRepo);
  });
  
  blocTest<TaskListBloc, TaskListState>(
    'emits [TaskListLoading, TaskListLoaded] when LoadTasks is added',
    build: () {
      when(mockRepo.getAllTasks()).thenAnswer((_) async => [mockTask]);
      return bloc;
    },
    act: (bloc) => bloc.add(LoadTasks()),
    expect: () => [
      TaskListLoading(),
      TaskListLoaded([mockTask]),
    ],
  );
  
  blocTest<TaskListBloc, TaskListState>(
    'AddTask persists before emitting',
    build: () => bloc,
    seed: () => TaskListLoaded([]),
    act: (bloc) => bloc.add(AddTask(mockTask)),
    verify: (_) {
      verifyInOrder([
        mockRepo.addTask(mockTask),  // Persist first
        // Then emit
      ]);
    },
  );
});
```

### 3. Data Sync
**Risk:** HIGH  
**Untested:**
- Sync to Firestore
- Sync from Firestore
- Conflict resolution
- Offline handling

### 4. Notification Scheduling
**Risk:** MEDIUM  
**Untested:**
- Reminder scheduling
- Timezone handling
- Notification cancellation

---

## Testing Strategy Recommendations

### 1. Unit Test Priority

| Component | Priority | Effort | Tests Needed |
|-----------|----------|--------|--------------|
| `TaskListBloc` | HIGH | Medium | 15-20 tests |
| `AuthService` | HIGH | Medium | 10-15 tests |
| `DataSyncService` | HIGH | High | 15-20 tests |
| `Task` model | HIGH | Low | 10 tests |
| `RepeatService` | MEDIUM | Medium | 10 tests |
| `NotificationService` | MEDIUM | High | 10-15 tests |
| `HomeScreenController` | LOW | Low | 5-10 tests |

### 2. Widget Test Priority

| Screen | Priority | Complexity |
|--------|----------|------------|
| `LoginScreen` | HIGH | Medium |
| `HomeScreen` | HIGH | High |
| `AddTaskDialog` | HIGH | Medium |
| `TaskItem` | MEDIUM | Low |
| `SettingsScreen` | LOW | Medium |

### 3. Integration Test Scenarios

```dart
// integration_test/task_flow_test.dart
void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  
  testWidgets('Complete task creation flow', (tester) async {
    await tester.pumpWidget(MyApp());
    
    // Navigate to add task
    await tester.tap(find.byIcon(Icons.add));
    await tester.pumpAndSettle();
    
    // Fill form
    await tester.enterText(find.byType(TextField).first, 'New Task');
    await tester.tap(find.text('Save'));
    await tester.pumpAndSettle();
    
    // Verify task appears
    expect(find.text('New Task'), findsOneWidget);
  });
}
```

---

## Mock Strategy

### Required Mocks

```dart
// test/mocks/mock_services.dart

@GenerateMocks([
  FirebaseAuth,
  FirebaseFirestore,
  GoogleSignIn,
  FlutterLocalNotificationsPlugin,
])
void main() {}

// Manual mocks for Hive
class MockHiveBox<T> extends Mock implements Box<T> {}

// Mock repositories
class MockTaskRepository extends Mock implements TaskRepository {
  @override
  Future<List<Task>> getAllTasks() async => [];
}
```

### Firebase Test Setup

```dart
// test/firebase_mock_setup.dart
import 'package:firebase_core_platform_interface/firebase_core_platform_interface.dart';

void setupFirebaseCoreMocks() {
  TestWidgetsFlutterBinding.ensureInitialized();
  
  MethodChannelFirebase.channel.setMockMethodCallHandler((call) async {
    if (call.method == 'Firebase#initializeCore') {
      return [
        {
          'name': '[DEFAULT]',
          'options': {
            'apiKey': 'test',
            'appId': 'test',
            'projectId': 'test',
            'messagingSenderId': 'test',
          },
        }
      ];
    }
    return null;
  });
}
```

---

## Test Configuration

### pubspec.yaml Additions

```yaml
dev_dependencies:
  flutter_test:
    sdk: flutter
  bloc_test: ^9.1.0
  mocktail: ^1.0.0
  # or
  mockito: ^5.4.0
  build_runner: ^2.4.13
  integration_test:
    sdk: flutter
  fake_cloud_firestore: ^2.0.0
  firebase_auth_mocks: ^0.12.0
```

### Test Script

```bash
#!/bin/bash
# scripts/run_tests.sh

echo "Running unit tests..."
flutter test --coverage

echo "Generating coverage report..."
genhtml coverage/lcov.info -o coverage/html

echo "Running integration tests..."
flutter test integration_test/
```

---

## Coverage Goals

### Immediate (Week 1-2)
- [ ] Enable widget tests with mocked Firebase
- [ ] Add TaskListBloc tests (15 tests)
- [ ] Add AuthService tests (10 tests)
- [ ] Target: 25% coverage

### Short-term (Month 1)
- [ ] Add DataSyncService tests
- [ ] Add model tests
- [ ] Add widget tests for critical screens
- [ ] Target: 50% coverage

### Long-term (Quarter 1)
- [ ] Add integration tests
- [ ] Add E2E tests
- [ ] Target: 70% coverage

---

## Action Items

| Priority | Task | Effort | Impact |
|----------|------|--------|--------|
| HIGH | Enable widget tests with mocks | Medium | High |
| HIGH | Add TaskListBloc tests | Medium | High |
| HIGH | Add AuthService tests | Medium | High |
| MEDIUM | Add model unit tests | Low | Medium |
| MEDIUM | Add DataSyncService tests | High | High |
| MEDIUM | Set up CI test pipeline | Medium | High |
| LOW | Add integration tests | High | Medium |
