# Firebase Analytics & Crashlytics Analysis

## Current Implementation

### File: `lib/services/analytics_service.dart`

### Analytics Events Tracked

| Category | Events | Coverage |
|----------|--------|----------|
| **User Actions** | login, logout, screen_view | ✅ Good |
| **Task Events** | task_created, task_completed, task_deleted, task_updated | ✅ Good |
| **Pomodoro Events** | pomodoro_started, pomodoro_completed, pomodoro_cancelled | ✅ Good |
| **Mood Events** | mood_recorded | ⚠️ Basic |
| **Category Events** | category_created, category_deleted | ✅ Good |
| **Notification Events** | notification_sent, notification_opened | ✅ Good |
| **Admin Events** | admin_panel_opened, admin_user_deleted, etc. | ✅ Comprehensive |
| **Export Events** | data_exported | ✅ Good |
| **Search Events** | search | ✅ Good |

---

## 🟢 Strengths

### 1. Singleton Pattern
```dart
static final AnalyticsService _instance = AnalyticsService._internal();
factory AnalyticsService() => _instance;
```
Good implementation ensuring single instance across app.

### 2. Debug Mode Handling
```dart
await _analytics.setAnalyticsCollectionEnabled(!kDebugMode);
```
Analytics disabled in debug mode to avoid polluting production data.

### 3. Comprehensive Admin Tracking
All admin actions are tracked for audit trail:
- User deletions
- User promotions
- Category CRUD
- Settings updates

### 4. Crashlytics Integration
```dart
FlutterError.onError = _crashlytics.recordFlutterFatalError;
PlatformDispatcher.instance.onError = (error, stack) {
  _crashlytics.recordError(error, stack, fatal: true);
  return true;
};
```
Catches both Flutter and platform errors.

---

## 🔴 Issues & Improvements

### 1. Missing Event Parameters
**Severity:** MEDIUM  
**Issue:** Some events lack useful context.

**Example:** `logMoodRecorded` only tracks level and hasNote:
```dart
Future<void> logMoodRecorded({required String moodLevel, bool hasNote = false}) async {
  await _logEvent('mood_recorded', parameters: {
    'mood_level': moodLevel, 
    'has_note': hasNote ? 'true' : 'false'
  });
}
```

**Recommendation:** Add more context:
```dart
Future<void> logMoodRecorded({
  required String moodLevel, 
  bool hasNote = false,
  int? energyLevel,
  int? focusLevel,
  int? stressLevel,
  List<String>? tags,
}) async {
  await _logEvent('mood_recorded', parameters: {
    'mood_level': moodLevel,
    'has_note': hasNote ? 'true' : 'false',
    if (energyLevel != null) 'energy_level': energyLevel,
    if (focusLevel != null) 'focus_level': focusLevel,
    if (stressLevel != null) 'stress_level': stressLevel,
    if (tags != null) 'tags_count': tags.length,
  });
}
```

### 2. No User Properties Set
**Severity:** MEDIUM  
**Issue:** `setUserProperty` method exists but not used systematically.

**Recommendation:** Set useful user properties:
```dart
Future<void> setUserProperties() async {
  final taskCount = await taskRepository.getAllTasks().length;
  await setUserProperty(name: 'task_count_bucket', value: _getBucket(taskCount));
  await setUserProperty(name: 'language', value: locale.languageCode);
  await setUserProperty(name: 'theme_mode', value: themeMode.name);
}
```

### 3. No Funnel Tracking
**Severity:** MEDIUM  
**Issue:** No conversion funnel for key flows.

**Recommendation:** Track onboarding funnel:
```dart
// Onboarding funnel
logOnboardingStep(int step, String name);
logOnboardingComplete();
logOnboardingAbandoned(int lastStep);

// Task creation funnel
logTaskCreationStart();
logTaskCreationComplete();
logTaskCreationAbandoned();
```

### 4. No Performance Monitoring
**Severity:** MEDIUM  
**Issue:** Firebase Performance Monitoring not implemented.

**Recommendation:**
```dart
import 'package:firebase_performance/firebase_performance.dart';

final Trace trace = FirebasePerformance.instance.newTrace('sync_tasks');
trace.start();
await syncTasks();
trace.stop();
```

### 5. Missing Revenue/Engagement Metrics
**Severity:** LOW  
**Issue:** No tracking for engagement metrics important for app store optimization.

**Recommendation:**
```dart
logSessionStart();
logSessionDuration(int seconds);
logDailyActiveUser();
logWeeklyActiveUser();
logRetention(int daysSinceInstall);
```

---

## Crashlytics Analysis

### 🟢 Current Coverage
- Flutter errors captured
- Platform errors captured
- User identifier set on login
- Custom logging available

### 🔴 Missing

#### 1. Non-Fatal Error Tracking
**Issue:** Only fatal errors tracked automatically.

**Recommendation:** Add non-fatal error tracking:
```dart
try {
  await riskyOperation();
} catch (e, stack) {
  analyticsService.recordError(
    exception: e, 
    stackTrace: stack, 
    fatal: false,
    reason: 'Failed during risky operation'
  );
}
```

#### 2. Custom Keys for Context
**Issue:** Limited use of custom keys.

**Recommendation:**
```dart
Future<void> setErrorContext({
  required String screen,
  required String action,
  Map<String, dynamic>? additionalContext,
}) async {
  await setCustomKey('current_screen', screen);
  await setCustomKey('last_action', action);
  await setCustomKey('task_count', taskCount);
  await setCustomKey('offline_mode', isOffline);
}
```

#### 3. Breadcrumb Logging
**Issue:** No breadcrumb trail before crashes.

**Recommendation:**
```dart
void logBreadcrumb(String message) {
  _crashlytics.log('[${DateTime.now().toIso8601String()}] $message');
}

// Usage
logBreadcrumb('User opened task list');
logBreadcrumb('User started creating task');
logBreadcrumb('User selected category: Work');
```

---

## Recommended Events to Add

| Event | Parameters | Purpose |
|-------|------------|---------|
| `app_open` | source (notification, widget, direct) | Track entry points |
| `feature_discovery` | feature_name | Track new feature adoption |
| `error_shown` | error_type, screen | Track user-facing errors |
| `sync_completed` | duration_ms, items_synced | Monitor sync performance |
| `offline_mode_entered` | - | Track connectivity issues |
| `tutorial_step` | step_number, skipped | Onboarding optimization |
| `settings_changed` | setting_name, old_value, new_value | Feature usage |

---

## Action Items

| Priority | Task | Effort | Impact |
|----------|------|--------|--------|
| HIGH | Add Firebase Performance Monitoring | Low | High |
| MEDIUM | Implement funnel tracking | Medium | High |
| MEDIUM | Set user properties | Low | Medium |
| MEDIUM | Add breadcrumb logging | Low | Medium |
| LOW | Expand event parameters | Medium | Medium |
| LOW | Add engagement metrics | Medium | Medium |
